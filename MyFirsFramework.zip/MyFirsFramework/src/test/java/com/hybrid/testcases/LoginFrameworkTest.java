package com.hybrid.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hybrid.pageobject.LoginPageObject;
import com.hybrid.utilities.BrowserFactory;
import com.hybrid.utilities.DataProvider;
import com.hybrid.utilities.helper;

public class LoginFrameworkTest extends baseclass {
	
	//WebDriver driver;
	@Test
	public void loginid()
	{
		//DataProvider dp=new DataProvider();
		
		LoginPageObject loginpage=PageFactory.initElements(driver, LoginPageObject.class);
		//LoginPageObject loginpage=new LoginPageObject(driver);
		loginpage.usercredentials(dp.getstringdata("login", 0, 0), dp.getstringdata("login", 0, 1));
		//BrowserFactory.quitBrowser(driver);
		//helper.screenshot(driver);
	

}}
