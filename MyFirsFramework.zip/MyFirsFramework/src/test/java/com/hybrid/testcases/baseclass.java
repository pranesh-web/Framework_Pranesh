package com.hybrid.testcases;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.hybrid.utilities.BrowserFactory;
import com.hybrid.utilities.DataProvider;
import com.hybrid.utilities.configdataprovider;
import com.hybrid.utilities.helper;

public class baseclass {
	
	 WebDriver driver;
	 DataProvider dp;
	 configdataprovider dpr;
	// helper hpr;
	 
	 @BeforeSuite
	 public void setupSuite()
	 {
		  dp=new DataProvider();
		  dpr=new configdataprovider();
	 }
	@BeforeClass
	public void startup()
	{
		driver=BrowserFactory.startapplication(driver, dpr.getdataBrowserconfig(), dpr.getdataurlconfig());
	}
	@AfterClass
	public void endup()
	{
		driver.quit();
	}
	@AfterMethod
	public void capturess(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
		helper.screenshot(driver);
			//hpr=new helper();
			//hpr.screenshot(driver);
		}
	}
	
	
	
	

}
