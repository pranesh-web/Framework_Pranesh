package com.hybrid.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataProvider  {
	
	XSSFWorkbook hssf;
	public DataProvider()
	{
		try {
			FileInputStream fi=new FileInputStream("./TestData/test.xlsx");
			 hssf=new XSSFWorkbook(fi);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	/*public String getstringdata(int sheetIndex,int row,int col )
		{
			
			return hssf.getSheetAt(sheetIndex).getRow(row).getCell(col).getStringCellValue() ;
			
		}
	
		public double getNumber(String sheetName,int row,int col)
		{
			return hssf.getSheet(sheetName).getRow(row).getCell(col).getNumericCellValue();
		}
		*/
	public String getstringdata( String sheetName,int row,int col )
	{
		return hssf.getSheet(sheetName).getRow(row).getCell(col).getStringCellValue();
	}

}
