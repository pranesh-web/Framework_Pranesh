package com.hybrid.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class configdataprovider {
	
	Properties pro;
	public configdataprovider()
	{
		File fp=new File("./Configuration/config.properties");
		try {
			FileInputStream fic=new FileInputStream(fp);
			pro=new Properties();
			try {
				pro.load(fic);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getgenericconfig(String keytosearch)
	{
		return pro.getProperty(keytosearch);
	}
	public String getdataBrowserconfig()
	{
		return pro.getProperty("Browser");
	}
	public String getdataurlconfig()
	{
		return pro.getProperty("UATURL");
	}

}
