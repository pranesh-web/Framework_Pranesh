package com.hybrid.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Test;

public class LoginPageObject {

	WebDriver driver;



	public  LoginPageObject(WebDriver driver)
	{
		this.driver=driver;
	}
	@FindBy(id="user_login")
	@CacheLookup
	WebElement userlogin;
	@FindBy(how=How.ID,using="user_pass")
	@CacheLookup
	WebElement userpass;
	@FindBy(how=How.ID,using="wp-submit")
	@CacheLookup
	WebElement submit;
	
	public void usercredentials(String uname,String upass)
	{
		userlogin.sendKeys(uname);
		userpass.sendKeys(upass);
		submit.click();
	}
}
